#Crie um programa que leia dois números e
#mostre a soma entre eles
n1 = int(input('Digite um numero inteiro: '))
n2 = int(input('Digite outro numero inteiro: '))
soma = n1+n2
print('A soma entre {} e {} é {} '.format( n1,n2,soma))

