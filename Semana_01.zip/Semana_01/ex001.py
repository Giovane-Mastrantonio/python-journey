print('Olá Mundo!')
msg="Olá, eu vou me tornar MILIONÁRIO!"
print(msg)
print('Agora vamos somar dois números\n')
n1=float(input('Digite um número: '))
n2=float(input('Digite outro número: '))
soma=n1+n2
print('O resultado é ', soma)
