# Crie um programa que leia o nome de uma pessoa
# e diga se ela tem "Silva" no nome
print('=== DIGITE SEU NOME ===')
nome = str(input('Digite seu nome: ')).strip()
print('SILVA' in nome.upper())

