nome=input("Digite seu nome: ")
print("É um prazer te conhecer,",nome,"!")
print("É um prazer te conhecer, {}!".format(nome))