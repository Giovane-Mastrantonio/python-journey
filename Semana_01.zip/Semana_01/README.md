# Semana 01

Descrição dos estudos realizados nesta semana.



\# Semana 01 – Lógica, Variáveis e Funções



✅ Estudo introdutório de Python, cobrindo:

\- Tipos primitivos

\- Entrada e saída

\- Operadores

\- Exercícios resolvidos



🔗 \[Voltar ao cronograma](../README.md)



